---
name: 社科量化研究方法库
description: "社科量化实证方法参考库，覆盖量表开发、信效度、共同方法偏差、测量不变性、EFA/CFA、SEM、中介调节、因果推断（DID/PSM/IV/RDD/DML）、统计结果表。用于设计研究方案、审稿把关方法严谨性、撰写 Methods/Results 章节、回应审稿方法意见。触发场景：问卷量表设计、信效度检验、CFA/SEM、中介效应、调节效应、因果推断、准实验设计、DID、倾向得分匹配、工具变量、统计表格规范化、方法部分写作、审稿方法质疑。内含反幻觉硬约束：不得编造量表来源、不得将相关性表述为因果、不得隐藏不显著结果。方法执行须配合本机统计环境，本库只提供设计与报告规范。"
metadata:
  version: "1.0.0"
  source: "抽取整合自 Drchronx/ai-agent-research-starter-kit（PolyForm Noncommercial 1.0.0，非商用）"
  integrated_on: "2026-11-17"
---

# 社科量化研究方法库

面向社会学、管理学、政治学、传播学、国际关系等社科领域的量化实证方法参考库。本库不改变论文的数据与结论，只提供**研究设计审查、方法选择、报告规范、审稿风险提示**四类知识。

## 定位与边界

- **只做方法把关，不做数据代算。** 本库提供设计逻辑、假设检查、报告结构与审稿风险清单；实际统计运算须在 R、Python、Stata、Mplus、SPSS 等环境中由用户完成并复核。
- **反幻觉为硬约束。** 每个方法分册均含 Hard Constraints，涉及"不得编造量表来源/信效度证据""不得将横截面相关表述为因果""不得隐藏不显著或不良结果"等底线，与本机永久要求一致。
- **与既有技能的关系。** 本库补充 `academic-paper`（写作流程）与 `thesis-tutor`（全流程引导）在量化方法细节上的空白；二者并行，不互相替代。

## 路由表（按需求选分册，只读对应文件）

| 需求场景 | 分册文件 |
|---|---|
| 选择/改编量表，概念操作化，翻译回译 | `references/scale-selection-adaptation.md` |
| 信度（alpha/omega/CR）与效度（AVE/HTMT/Fornell-Larcker） | `references/scale-reliability-validity.md` |
| 探索/验证因子分析，模型拟合指标 | `references/efa-cfa-measurement-model.md` |
| 共同方法偏差、测量不变性、跨组等价 | `references/common-method-bias-invariance.md` |
| 结构方程、潜变量路径、竞争模型 | `references/sem-cfa-path-latent.md` |
| 中介、调节、有调节的中介（PROCESS 类） | `references/process-mediation-moderation.md` |
| 因果主张审计、DAG、识别假设、混杂/坏控制 | `references/causal-inference-design-audit.md` |
| DID/事件研究、PSM、IV、RDD、DML 具体设计 | `references/did-psm-iv-rdd-dml-event-study.md` |
| 多层级/纵向数据建模 | `references/multilevel-longitudinal-modeling.md` |
| 统计结果表、Results 段落、效应量与精确 p 值 | `references/statistical-results-tables.md` |
| 问卷测量章节与附录写作模板 | `references/questionnaire-reporting-template.md` |

## 使用流程

1. 判定用户处于**设计阶段**（尚未收数据）、**分析阶段**（已有数据）、**写作阶段**（撰写 Methods/Results）还是**审稿回应阶段**。
2. 按路由表只读取相关分册，不全文加载。
3. 依分册 Workflow 输出结构化清单；凡分册标注 Hard Constraints 的，逐条自查并在输出中说明是否触发。
4. 涉及具体数值、量表文献、软件输出时，明确标注"须由用户提供并经其复核"，不代填、不编造。

## 数据来源与许可

本库内容抽取整合自 GitHub 项目 `Drchronx/ai-agent-research-starter-kit` 的 `13_量表开发与心理测量Skills` 与 `14_高级统计机制与因果推断Skills` 两类，原始许可 PolyForm Noncommercial 1.0.0（限非商用的学习、研究、教学与改编）。整合时保留各方法的核心工作流与硬约束，未逐字复制长篇内容。多层级建模分册（`multilevel-longitudinal-modeling`）因原始文件未纳入本轮抽取范围，暂以路由占位，需要时再补。
