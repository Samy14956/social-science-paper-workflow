#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""社科论文全流程 · 跨平台安装器

在 Windows / macOS / Linux 上把本技能包安装到 WorkBuddy：
  1) 将 4 个技能复制到 WorkBuddy 技能目录（同名目录先备份，不覆盖历史内容）
  2) 将 paper-tools-mcp 复制到目标目录
  3) 合并 ~/.workbuddy/mcp.json —— 仅新增 paper-tools-mcp 条目，保留全部既有条目
  4) 可选执行 uv sync 安装 MCP 运行依赖

用法：
  python install.py                       # 安装（不自动装依赖）
  python install.py --with-deps           # 安装并执行 uv sync
  python install.py --skills-dir DIR --mcp-dir DIR --mcp-json FILE
  python install.py --dry-run             # 只打印将要执行的操作
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
SKILLS = ["社科量化研究方法库", "deep-research", "zotero", "literature-review"]
MCP_SERVER_NAME = "paper-tools-mcp"


def log(msg: str) -> None:
    print(f"[社科论文全流程] {msg}")


def backup_if_exists(target: Path) -> None:
    if target.exists():
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        bak = target.with_name(f"{target.name}.bak.{stamp}")
        shutil.move(str(target), str(bak))
        log(f"已备份既有目录：{bak}")


def merge_mcp_json(path: Path, mcp_dir: Path, skills_dir: Path, dry_run: bool) -> None:
    if path.exists():
        try:
            cfg = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise SystemExit(f"mcp.json 解析失败，已中止以免破坏配置：{exc}")
    else:
        cfg = {}

    servers = cfg.setdefault("mcpServers", {})
    if MCP_SERVER_NAME in servers and not dry_run:
        log(f"mcp.json 中已存在 {MCP_SERVER_NAME}，将保留原条目不覆盖")
        return

    base_dir = str(Path.cwd())
    entry = {
        "type": "stdio",
        "command": "uv",
        "args": [
            "run",
            "--project",
            mcp_dir.as_posix(),
            "python",
            "-m",
            "paper_tools_mcp.server",
        ],
        "env": {
            "PAPER_TOOLS_BASE_DIR": base_dir,
            "PAPER_TOOLS_SKILLS_DIR": skills_dir.as_posix(),
        },
    }
    if dry_run:
        log(f"[dry-run] 将向 {path} 写入条目：{MCP_SERVER_NAME}")
        return

    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        bak = path.with_name(f"{path.name}.bak.{stamp}")
        shutil.copy2(str(path), str(bak))
        log(f"已备份 mcp.json：{bak}")
    servers[MCP_SERVER_NAME] = entry
    path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    log(f"已合并 mcp.json，新增 {MCP_SERVER_NAME}（既有条目全部保留）")


def main() -> None:
    ap = argparse.ArgumentParser(description="社科论文全流程 · 跨平台安装器")
    ap.add_argument("--skills-dir", default=str(Path.home() / ".workbuddy" / "skills"),
                    help="WorkBuddy 技能目录（默认 ~/.workbuddy/skills）")
    ap.add_argument("--mcp-dir", default=str(Path.home() / ".workbuddy" / "mcp-servers" / "paper-tools-mcp"),
                    help="MCP 服务安装目录")
    ap.add_argument("--mcp-json", default=str(Path.home() / ".workbuddy" / "mcp.json"),
                    help="WorkBuddy MCP 配置文件")
    ap.add_argument("--with-deps", action="store_true", help="安装后执行 uv sync")
    ap.add_argument("--dry-run", action="store_true", help="只打印操作，不落盘")
    args = ap.parse_args()

    skills_dir = Path(args.skills_dir).expanduser().resolve()
    mcp_dir = Path(args.mcp_dir).expanduser().resolve()
    mcp_json = Path(args.mcp_json).expanduser().resolve()

    log(f"技能目录：{skills_dir}")
    log(f"MCP 目录：{mcp_dir}")
    log(f"MCP 配置：{mcp_json}")

    for name in SKILLS:
        src = HERE / "skills" / name
        dst = skills_dir / name
        if not src.is_dir():
            raise SystemExit(f"技能包内容缺失：{src}")
        if args.dry_run:
            log(f"[dry-run] 将安装技能：{name}")
            continue
        skills_dir.mkdir(parents=True, exist_ok=True)
        backup_if_exists(dst)
        shutil.copytree(str(src), str(dst))
        meta = dst / "_user_meta.json"
        meta.write_text(json.dumps(
            {"name": name, "installedAt": int(datetime.now().timestamp() * 1000),
             "source": "社科论文全流程技能包"},
            ensure_ascii=False, indent=2), encoding="utf-8")
        log(f"已安装技能：{name}")

    src_mcp = HERE / "mcp" / "paper-tools-mcp"
    if not src_mcp.is_dir():
        raise SystemExit(f"MCP 源码缺失：{src_mcp}")
    if args.dry_run:
        log("[dry-run] 将复制 paper-tools-mcp 源码")
    else:
        mcp_dir.parent.mkdir(parents=True, exist_ok=True)
        backup_if_exists(mcp_dir)
        shutil.copytree(str(src_mcp), str(mcp_dir),
                        ignore=shutil.ignore_patterns(".venv", "__pycache__", "*.pyc"))
        log("已复制 paper-tools-mcp 源码")

    merge_mcp_json(mcp_json, mcp_dir, skills_dir, args.dry_run)

    if args.with_deps and not args.dry_run:
        log("执行 uv sync 安装依赖…")
        r = subprocess.run(["uv", "sync"], cwd=str(mcp_dir))
        if r.returncode != 0:
            log("依赖安装失败，请手动在该目录执行 uv sync")

    log("安装完成。请重启 WorkBuddy，并在连接器管理页信任 paper-tools-mcp。")
    log("可选语义检索（需下载约数百 MB 模型）：在该目录执行 uv sync --extra semantic")


if __name__ == "__main__":
    main()
