# 来源与许可声明

本技能包为整合分发包，各组件版权与许可归属如下。使用者须遵守各组件原始许可。

| 组件 | 来源 | 许可 | 商用 |
|---|---|---|---|
| 社科量化研究方法库 | 改编自 Drchronx/ai-agent-research-starter-kit（GitHub）的 13/14 类方法技能，经整合、重写路由与本地化修订 | PolyForm Noncommercial 1.0.0 | 禁止 |
| deep-research | WorkBuddy 用户导出包（笔杆子导出包 global-skills） | 遵循原始发布者许可 | 依原始许可 |
| zotero | WorkBuddy 用户导出包（workspace-skills） | 遵循原始发布者许可 | 依原始许可 |
| literature-review | WorkBuddy 用户导出包（workspace-skills） | 遵循原始发布者许可 | 依原始许可 |
| paper-tools-mcp | BH2-4/paper-craft-pipeline（GitHub）mcp/paper-tools-mcp | Apache-2.0 | 允许 |

## 对 paper-tools-mcp 所做的适配修改

为保证在当前 Python / MCP 运行环境可安装、可启动，对上游源码做了三处最小修改，均不改变工具语义：

1. `pyproject.toml`：将 `sentence-transformers` 移入可选依赖组 `semantic`（默认不安装，源码自动降级为关键词检索）；将 `mcp[cli]` 约束为 `<2`，因上游代码使用 mcp 1.x 的 `FastMCP` API。
2. `src/paper_tools_mcp/tools/validation.py`：新增 `from docx.document import Document`，并将 5 个工具函数中的 `doc: "Document | None"` 改为 `doc: object`，使 FastMCP 可解析类型注解（原写法在 mcp 1.30 / pydantic 2 下抛错）。

上述修改已在此环境实测：24 个工具全部成功加载，`validate_word_count`、`assess_aigc_risk` 均可正常调用。

## 免责声明

本包按"现状"提供。文献检索结果、统计分析与文稿内容须经人工复核，不得将工具输出直接作为可回溯事实引用。使用者须自行确保其使用行为符合所属机构的数据安全与保密规定。
