# paper-tools-mcp

为 [paper-craft-pipeline](../..) 提供学术写作辅助工具的 FastMCP 服务端，共 **24 个工具**，覆盖字数校验、引用校验、版式渲染、参考文献构建、AIGC 风险评估、文献卡、DOCX 模板分析、Excel 校验等环节。

## 安装

```bash
uv sync
```

要求 Python ≥ 3.11。运行时依赖在 `pyproject.toml` 中声明（`mcp[cli]`、`sentence-transformers`、`numpy`、`python-docx`）。

## 配置

```bash
cp .env.example .env        # 填入模型、路径等本地变量
```

`PAPER_TOOLS_BASE_DIR` 用于约束文件读写的允许目录（沙箱白名单），同时被 `tests/test_final_comprehensive.py`、`tests/test_fixes.py`、`tests/test_stage2_fixes.py` 用于定位外部 `skills/` 与 `agents/` 目录。如需接入 MCP 客户端，可参考 `mcp-config.example.json`，最小接入片段示例：

```jsonc
{
  "mcpServers": {
    "paper-tools-mcp": {
      "command": "uv",
      "args": ["--directory", "<your-project>/mcp/paper-tools-mcp", "run", "python", "-m", "paper_tools_mcp.server"]
    }
  }
}
```

> `<your-project>` 替换为本仓库的本地克隆根目录。

## 工具清单（按类别）

详细参数与返回结构见仓库 `docs/mcp-tools-reference.md`。

- **字数与结构校验**：`validate_word_count`、`validate_markdown_structure`、`validate_assets`
- **引用与参考文献**：`validate_citations`、`validate_chapter_citations`、`validate_citation_order`、`build_reference_list`
- **DOCX 版式校验**：`validate_docx_styles`、`validate_docx_layout`、`validate_docx_fonts`、`validate_docx_sections`、`validate_docx_references`
- **版式渲染流水线**：`pandoc_to_docx`、`build_preflight_docx`、`apply_minimax_c2`、`apply_pandoc_templated`、`run_format_pipeline`
- **AIGC 风险评估**：`assess_aigc_risk`
- **文献卡与语义检索**：`get_literature_cards`、`search_blocks`、`query_data_facts`
- **DOCX 模板分析**：`analyze_docx_template`
- **Excel 校验**：`query_excel_data`、`validate_excel_formulas`

## 测试

```bash
uv run pytest                         # 内部单元测试（src/paper_tools_mcp/tests/）
uv run pytest tests/                  # 额外集成/综合校验（依赖 PAPER_TOOLS_BASE_DIR 下的 skills/ 与 agents/）
```

## License

Apache-2.0
